-----------------------------------------
>>> Important Additional Notes & Tips:
-----------------------------------------

1. To get AppLocker policies to actually work, you might have to enable the "Application Identity" service and set it to start automatically if it isn't already. This requires a special command because it is a protected process (as opposed to just opening the services menu).
	
	- Simply open command prompt or powershell (as admin!) and enter:
		sc.exe config appidsvc start= auto
	
	- If interested, here are more details: https://learn.microsoft.com/en-us/windows/security/application-security/application-control/windows-defender-application-control/applocker/configure-the-application-identity-service



-----------------------------------------
>>> Notes about the included files:
-----------------------------------------


1. You can import the starter AppLocker policy by going to the AppLocker settings management console, right click on "AppLocker" on the left, and hit "Import Policy". Then select the XML file.

	--- WARNING: This will completely overwrite any rules you already created.
	
	--- WARNING: After importing the policy, there are some rules that include paths that you will need to update for yourself, because they specify an exact username path. Look for rule names that have "(Change path to your username)" at the end. 
		- There should be 5 total, and in all of them, look for where it says "WHATEVERUSERNAME" and replace it with your own. 
		- Three of these rules are the "[TOGGLE TEMPORARY]"	rules (in the executable, script, and DLL sections). Go to the 'Path' tab for each rule and change the path there.
		- The other two are the rules that mention "PWSH" and "PWSH.exe" in the executables section. For these you actually need to adjust one of the Exception paths, so go to the "Exceptions" tab, find the exception entry with "WHATEVERUSERNAME" and edit it to replace that with your actual username.
	
	--- Note: If you do not use PowerShell 7, aka PowerShell Core (which is a separate version of powershell that you'd have download separately), or do not know what that is, you can probably go into the two Executable rules mentioning "PWSH" and "PWSH.exe", and just delete all of the exceptions for those rules. They are there to allow PowerShell 7 to function in their proper install directory, but if you don't use it, those exceptions are not necessary. And keep in mind I am talking about only deleting the exceptions for those two rules, not the whole rules.

---------------------------------------------------------------------------------------------

2. I have also included second larger policy that includes rules based on this article by Microsoft about legitimate programs that can be used to bypass AppLocker and Windows Defender Application Control:
	--- https://learn.microsoft.com/en-us/windows/security/application-security/application-control/windows-defender-application-control/design/applications-that-can-bypass-wdac
	
	--- That policy will be called "AppLocker Policy - Thio Starter Policy + MS Recommended Blocks.xml"
	--- You'll see all those rules wil be named starting with "___MS Recommended Block: " to make it easier to distinguish 
	
	Note: I tried to use publisher rules where possible for these, but not all of them are digitally signed by Microsoft for some reason. For the rest I used path rules. Still, it should give added protection. If you need to use any of those programs, you can of course remove the individual rule for it.

---------------------------------------------------------------------------------------------

3. You can import the custom Event Viewer filters by opening the Event Viewer, then on the left panel, right click "Custom Views" and click "Import Custom View", then select the XML file.

	--- Note: I've added several custom Event Viewer log filters you might want to use. You'll have the option to organize them into folders when you import them. Just click where it says "New Folder". 
	
	--- Note: Specifically, in addition to the filter that shows all AppLocker block events, I've included 4 more which are the same as the 4 pre-made logs found in the "Applications and Services Log" section of Event Viewer. Except for these I have made them so they only show blocked events, whereas the pre-made ones include literally every event, even files allowed to run, which is nearly impossible to sift through.
	
	--- Tip: It might be more convenient to use the type-specific block filters because often times the log gets filled up with PowerShell's test scripts which always get blocked (these get blocked on purpose by the system, so do not make a rule to allow them).
	
	--- Tip: If you're wondering how to create a new folder for Custom Views in the left panel, there seems to only be two ways to do so:
		1. By right clicking an existing custom filter and selecting "Copy Custom View", which will bring up the window with the option to create a new folder.
		2. When importing a custom filter XML file, which also brings up that same window.
		
---------------------------------------------------------------------------------------------


4. I've found it to be annoying to have the Event Viewer log filled up with the "PSSCRIPTPOLICYTEST" entries, and unfortunately Event Viewer has no way to filter out entries with specific text. But I did find a free program called "Event Log Explorer" that can do that, and it is free for personal home use. I'll also include a "workspace" file I made that should automatically be set up to show your all blocked events excluding the test script events. You can open it by going to File > Open Workspace. The file is in the "Other Resources" folder.
	
	--- Here is the page to download: https://eventlogxp.com/download.php?s=1&u=h
	--- Usual disclaimer: I'm not associated with that software in any way so I offer no guarantees, use at your own risk, etc. That being said, I have been using it myself and it seems to work well.
	
		
---------------------------------------------------------------------------------------------

5. I have included a PowerShell script called "CheckMachinePolicy.ps1" that upon running, will warn you if your 'MachinePolicy' scope ExecutionPolicy is anything other than AllSigned or Restricted. I created this so it could be run as a scheduled task at login, in case I forget to change the policy back at some point. I have also included the scheduled task that you can import directly into Task Scheduler by right clicking and hitting "Import Task". The task is preset to run when the user logs in.
	
	Note: The script is written so it doesn't display anything if the policy is AllSigned or Restricted. It only displays a warning if it's not.
	
	Note: You will need to update the scheduled task to use the path to the script for wherever you put it. Go to the 'Actions' Tab, then hit 'Edit', then update the "Add Arguments" box with the command below, but just replace with your own path. The "Program/Script" box should just say 'cmd'. The command below is also in the description box of the task so you can view it any time.
	
	/c start /min "" powershell -File "C:\Your\Path\CheckMachinePolicy.ps1"


---------------------------------------------------------------------------------------------

6. It turns out you actually CAN add the 'PowerShell Core' Group Policy settings to the Group Policy Editor without having to install PowerShell 7. I'd recommend doing this and setting those settings to use the same ones as Windows PowerShell like I showed in the video (at around 48:35).
	
	- Here is how to add the policy settings without installing PowerShell 7:
		1. Go to the latest release of PowerShell from Microsoft's GitHub repo here: https://github.com/PowerShell/PowerShell/releases
		2. Under 'Assets' for the latest release, look for the one that ends with "win-x64.zip" and download that. For example, as of this writing it is "PowerShell-7.3.6-win-x64.zip". (Note, you might have to click to expand the list assets)
		3. After extracting the zip folder, look for the following two files: "PowerShellCoreExecutionPolicy.admx", and "PowerShellCoreExecutionPolicy.adml"
		4. Copy the "PowerShellCoreExecutionPolicy.admx" file into the directory "C:\Windows\PolicyDefinitions"
		5. Copy the "PowerShellCoreExecutionPolicy.adml" file into the directory "C:\Windows\PolicyDefinitions\en-US"
			- Note those are different directories, the adml goes into a subdirectory for your language.
			- If you don't have your computer set to english, I think you can also just copy the .adml file into whatever language folder you do use.
		6. Now when you open Group Policy Editor, you should see the "PowerShell Core" settings under 'Administrative Templates' (for both 'Computer Configuration' and 'User Configuration') like seen in the video.
			- I would then go into the PowerShell Core settings there and at least change the 'Turn on Script Execution' setting so that you have "Use Windows Powershell Policy setting" so it will always just match the other one.


=============================================================================================
=============================================================================================
=============================================================================================

Thio's AppLocker Resource Pack
Version 6 - Updated: February 14, 2024


----- Changelog -----

Version 2:
	- Added policy with Microsoft recommended blocks
	- Updated starter rule names to begin with "---- Starter Rules: " to make them easier to distinguish from rules you might add later
	
	
Version 3:
	- Added CheckMachinePolicy.ps1 and Associated scheduled task xml file
	- Organized resources into folders
	
Version 4:
	- Added instructions on how to add 'PowerShell Core' group policy settings without having to install PowerShell 7
	
Version 5:
	- Added new section at top of ReadMe for additional notes and instructions
	- Added note about enabling Application Identity service.
	
Version 6:
	- Fixed some typos/grammar in ReadMe file
	- Re-signed CheckMachinePolicy.ps1 script using sha256 instead of sha1